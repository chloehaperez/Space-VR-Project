Diverse Space Skybox

How to use the Skybox
=====================

1. Import the package into your Unity Scene/Project
2. Locate the Material folder that contains the "DiverseSpaceMaterial" file (It is a Material with a RenderFX/Skybox Shader selected)
3. Click on the Edit menu, then choose "Render Settings"
4. Drag and drop the "DiverseSpaceMaterial" file onto the "Skybox material" item in the Inspector panel for your Render Settings.
5. You are done! You should now see the Galactic Green skybox in your scene.